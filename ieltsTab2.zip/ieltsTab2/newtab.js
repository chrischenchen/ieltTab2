


// 使用 fetch 方法获取数据
fetch('https://ielts-uqtq.onrender.com/greet')
  .then(response => response.json())
  .then(data => {


    // 随机选择5个单词及对应的中文
    const selectedWords = getRandomWords(data, 5);

    // 更新页面内容
    for (let i = 0; i < selectedWords.length; i++) {
      const wordElement = document.getElementById(`word${i + 1}`);
      const chineseElement = document.getElementById(`chinese${i + 1}`);
      wordElement.textContent = selectedWords[i].Word;
      chineseElement.textContent = selectedWords[i].Chinese;
    }

    var poemContainer = document.getElementById("poemContainer");
    // poemContainer.style.backgroundColor = "royalblue";
    poemContainer.style.padding = "25px";
    poemContainer.style.border = "5px solid #ddbabe";


    var cloudDiv = document.getElementById("cloud"); // 获取具有 id "cloud" 的 div 元素

    // 创建 span 元素并插入 Emoji
    var spanElement = document.createElement("span");
    spanElement.innerHTML = "\uD83D\uDC40";
    cloudDiv.appendChild(spanElement);


    const buttonContainer = document.getElementById("button-container");
    buttonContainer.style.display = "block";


    
 
  })
  .catch(error => {
    console.error('An error occurred:', error);
  });



// 从数组中随机选择指定数量的元素
function getRandomWords(array, count) {
  const shuffledArray = array.slice(); // 复制数组以避免修改原始数据
  for (let i = shuffledArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffledArray[i], shuffledArray[j]] = [shuffledArray[j], shuffledArray[i]];
  }
  return shuffledArray.slice(0, count);
}


document.addEventListener("DOMContentLoaded", function () {
  // Fetch and initial word display code


  // const buttonContainer = document.getElementById("button-container");
  // buttonContainer.style.display = "block";

  // Select the button element
  const customButton = document.querySelector(".custom-button");

  // Add a click event listener to the button
  customButton.addEventListener("click", function () {
    // Fetch new words and update the page content
    fetch('https://ielts-uqtq.onrender.com/greet')
      .then(response => response.json())
      .then(data => {


        const selectedWords = getRandomWords(data, 5);

        for (let i = 0; i < selectedWords.length; i++) {
          const wordElement = document.getElementById(`word${i + 1}`);
          const chineseElement = document.getElementById(`chinese${i + 1}`);
          wordElement.textContent = selectedWords[i].Word;
          chineseElement.textContent = selectedWords[i].Chinese;
        }



      })
      .catch(error => {
        console.error('An error occurred:', error);
      });
  });
});


  // 获取按钮元素和中文单词元素
  const toggleButton = document.getElementById('toggleButton');
  const chineseWords = document.querySelectorAll('.chinese');

  // 初始化按钮状态和事件监听器
  let isButtonSelected = true; // 初始状态为选中
  toggleButton.addEventListener('click', toggleChineseVisibility);

  // 切换按钮状态和中文单词的显示样式
  function toggleChineseVisibility() {
    isButtonSelected = !isButtonSelected;
    const displayValue = isButtonSelected ? 'inline-block' : 'none';

    // 遍历中文单词元素，设置样式
    chineseWords.forEach(element => {
      element.style.display = displayValue;
    });

    // 更新按钮文本
    toggleButton.textContent = isButtonSelected ? 'Hide Chinese' : 'Show Chinese';
    toggleButton.classList.toggle('selected');
  }